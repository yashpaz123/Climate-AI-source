
var selectedLat;
var selectedLon;

var sliderSize;

var s = function(p) {
  var startCoords = [51.505, -0.09];

  var map;
  var popup;
  var marker;
  
  p.setup = function() {
    p.noCanvas();
    
    map = L.map('mapid').setView(startCoords, 8);
    popup = L.popup();
    marker = L.marker();
    selectedLat = startCoords[0].toFixed(6);
    selectedLon = startCoords[1].toFixed(6);
    

    L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    map.on('click', onMapClick);
  }

  p.draw = function() {}

  function onMapClick(e) {
    // popup
    //   .setLatLng(e.latlng)
    //   .setContent(e.latlng.lat.toFixed(6) + ", " + e.latlng.lng.toFixed(6))
    //   .openOn(map);
    marker
      .setLatLng(e.latlng)
      .bindPopup(e.latlng.lat.toFixed(6) + ", " + e.latlng.lng.toFixed(6))
      .addTo(map)
      .openPopup();
    selectedLat = e.latlng.lat.toFixed(6);
    selectedLon = e.latlng.lng.toFixed(6);
  }

  // p.mouseWheel = function(event) {
  //   return false;
  // }
}
var p1 = new p5(s, 'c1');



var t = function(p) {
  var canvas;
  var sliderWidth = 400;

  p.setup = function() {
    canvas = p.createCanvas(p.windowWidth, 20);
    p.noLoop();

    sliderSize = p.createSlider(200, 5000, 1000);
    updateSliders();
    sliderSize.style('width', sliderWidth.toString()+'px');
  };

  p.draw = function() {
    p.background(214, 234, 250);
    p.fill(0);
    
    p.text(sliderSize.value()+" pixels", p.width/2+sliderWidth/2-p.textWidth(sliderSize.value()+" pixels")/2+10, 12);
  };
  
  p.mousePressed = function() {
    p.redraw();
  }
  p.mouseReleased = function() {
    p.redraw();
  }
  p.mouseDragged = function() {
    p.redraw();
  }
  p.windowResized = function() {
    p.resizeCanvas(p.windowWidth, 20);
    updateSliders();
    p.redraw();
  }
  
  function updateSliders() {
    sliderSize.position(p.width/2-sliderWidth/2-p.textWidth(sliderSize.value()+" pixels")/2, canvas.position().y);
  }
};
var p2 = new p5(t, 'c2');



















var viewer = function(p) {
  var canvas;
  var hmouseX = -1;
  var hmouseY = -1;
  var record_hmouse = true;
  var numFramesLeft = 5;
  var downloadButton;
  var downloadButtonSize = [150, 40];

  var playbar_height = 60;
  var playbar_slider;
  var imageViewerX, imageViewerY, imageViewerW, imageViewerH;
  var imageViewer_padding = 15;
  var mouseOverImageViewer = false;
  var imageViewerSelectedImage = [0, 0];
  var imageTranslation = [0, 0];
  var imageScale = 1;
  var minImageScale = 1;
  var maxImageScale = 30;
  var imageViewerSelectedPoint = null;
  var selectionButtons_height = 40;

  var TCI_data = [];
  var NDVI_data = [];
  var DATE_data = [];
  var errorMessage = "null";

  var checkImageAvailabilityFrequency = 5;
  var httpURL = "http://localhost:8500"; // 10.0.0.227
  var processID = "abcd";
  var downloading = false;
  var waitForImageResponse = false;
  var loadingImageData = false;
  var numberOfImageSets;

  var startDateString;
  var endDateString;

  p.setup = function() {
    canvas = p.createCanvas(p.windowWidth, p.windowHeight);
    p.frameRate(60);
    // p.noLoop();

    downloadButton = p.createButton('Download Data');
    updateDownloadButton();
    downloadButton.style('font-size', '20px');
    downloadButton.size(downloadButtonSize[0], downloadButtonSize[1]);
    downloadButton.mouseClicked(downloadData);

    playbar_slider = p.createSlider(0, 0, 0);

    // temporary...
    // var url1 = "https://cdn.vox-cdn.com/thumbor/5z9rggTZC1cf_SdvHzVh0SFggGY=/0x0:1173x782/1400x1050/filters:focal(0x0:1173x782):format(jpeg)/cdn.vox-cdn.com/uploads/chorus_image/image/49965571/google-maps-earth-1.0.0.jpg";
    // TCI_data.push(p.loadImage(url1));
    // var url2 = "https://cdn.vox-cdn.com/thumbor/r-LVOJNLnVNTrLwFuyKewksnm3o=/0x0:1200x587/1720x0/filters:focal(0x0:1200x587):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/6713193/google-maps-earth-satellite-imagery-2016-5.0.jpg";
    // NDVI_data.push(p.loadImage(url2));
  };

  p.draw = function() {
    p.background(214, 234, 250);
    
    // p.strokeWeight(0);
    // p.fill(0);
    // p.text(selectedLat+", "+selectedLon, 100, 500);
    // p.text(localStorage.getItem('startDate'), 100, 600);
    // p.text(localStorage.getItem('endDate'), 100, 700);

    drawInterface();

    if(downloading) {
      if(waitForImageResponse && p.frameCount % (60*checkImageAvailabilityFrequency) == 0) {
        checkImageDataAvailability();
      }
      if(loadingImageData) {
        getImageData();
      }

      p.noStroke();
      p.fill(214, 234, 250, 150);
      p.rect(-1, -1, p.width+2, p.height-2);
      var radius = (p.width+p.height)/50;
      var thickness = (p.width+p.height)/400;
      showLoadingSpinner(p.width/2, p.height/2, radius, thickness);
      p.textSize(14);
      p.fill(0);
      p.textAlign(p.CENTER);
      var downloadingText = "Please wait while satellite images are processing\nThis will only take a minute";
      p.strokeWeight(0);
      p.text(downloadingText, p.width/2, p.height/2+radius+thickness+20);
      numFramesLeft--;
      if(numFramesLeft == 0) {
        p.noLoop();
      }
    }
  };
  
  p.mouseMoved = function() {
    if(!downloading) {
      p.redraw();
    }
  }
  p.mousePressed = function() {
    if(!downloading) {
      p.redraw();
    }
    if(record_hmouse) {
      hmouseX = p.mouseX;
      hmouseY = p.mouseY;
      record_hmouse = false;
    }
  }
  p.mouseReleased = function() {
    if(!downloading) {
      p.redraw();
    }
    hmouseX = -1;
    hmouseY = -1;
    record_hmouse = true;
  }
  p.mouseDragged = function() {
    if(!downloading) {
      p.redraw();
    }
  }
  p.mouseWheel = function(event) {
    if(!downloading) {
      p.redraw();
    }
    if(mouseOverImageViewer && TCI_data.length > 0) {
      var relativeMouseX = (p.mouseX-imageViewerX) / imageViewerW;
      var relativeMouseY = (p.mouseY-imageViewerY) / imageViewerH;
      var zoomPower = Math.pow(1.1, -event.delta/10);
      imageZoom(relativeMouseX, relativeMouseY, zoomPower);
      if(imageScale < minImageScale) {
        imageZoom(relativeMouseX, relativeMouseY, minImageScale/imageScale);
      }
      if(imageScale > maxImageScale) {
        imageZoom(relativeMouseX, relativeMouseY, maxImageScale/imageScale);
      }
      imageViewerEdgeCaseTransformation();
      return false;
    }
  }
  p.keyPressed = function() {
    if(!downloading) {
      p.redraw();
    }
  }
  p.keyReleased = function() {
    if(!downloading) {
      p.redraw();
    }
  }
  p.windowResized = function() {
    p.resizeCanvas(p.max(p.windowWidth, 400), p.max(p.windowHeight, 400));
    updateDownloadButton();
    if(!downloading) {
      p.redraw();
    }
  }

  function updateDownloadButton() {
    downloadButton.position(p.width/2-downloadButtonSize[0]/2, 19);
  }

  function showLoadingSpinner(x, y, r, t) {
    var counter = p.frameCount/10;
    p.noFill();
    p.strokeWeight(t+1);
    // p.stroke(157, 187, 200);
    p.stroke(214, 234, 250);
    p.ellipse(x, y, r*2, r*2);
    p.strokeWeight(t);
    // p.stroke(255);
    p.stroke(137, 167, 220);
    p.arc(x, y, r*2, r*2, counter, counter+p.sin(counter/2)+1);
  }

  function mouseBetween(x1, y1, x2, y2) {
    return p.mouseX > x1 && p.mouseX < x2 && p.mouseY > y1 && p.mouseY < y2;
  }
  function hmouseBetween(x1, y1, x2, y2) {
    return hmouseX > x1 && hmouseX < x2 && hmouseY > y1 && hmouseY < y2;
  }
  function redrawFrames(numFrames) {
    p.loop();
    numFramesLeft = numFrames;
  }
  function imageZoom(x, y, p) {
    imageTranslation[0] -= x;
    imageTranslation[1] -= y;
    imageScale *= p;
    imageTranslation[0] *= p;
    imageTranslation[1] *= p;
    imageTranslation[0] += x;
    imageTranslation[1] += y;
  }
  function imageViewerEdgeCaseTransformation() {
    if(imageTranslation[0] > 0) {
      imageTranslation[0] = 0;
    }
    if(imageTranslation[1] > 0) {
      imageTranslation[1] = 0;
    }
    if(imageTranslation[0] < 1-imageScale) {
      imageTranslation[0] = 1-imageScale;
    }
    if(imageTranslation[1] < 1-imageScale) {
      imageTranslation[1] = 1-imageScale;
    }
  }
  function updatePlaybarSlider() {
    playbar_slider.position(imageViewerX+imageViewerW/6, imageViewerY-imageViewer_padding-playbar_height/2+6.5);
    playbar_slider.style('width', imageViewerW*2/3+'px');
  }

  function drawInterface() {
    // Image viewer... (middle)
    var imageViewer_sizeX = p.width - imageViewer_padding*2;
    var imageViewer_sizeY = p.height - downloadButtonSize[1] - 20 - playbar_height - selectionButtons_height - imageViewer_padding*2;
    var imageViewer_size = p.max(p.min(imageViewer_sizeX, imageViewer_sizeY), 1);
    imageViewerX = p.width/2-imageViewer_size/2;
    imageViewerY = downloadButtonSize[1]+20+playbar_height;
    imageViewerW = imageViewer_size;
    imageViewerH = imageViewer_size;
    p.fill(0);
    p.noStroke();
    p.rect(imageViewerX, imageViewerY, imageViewerW, imageViewerH);
    p.textAlign(p.CENTER);
    if(!downloading) {
      if(errorMessage == "null") {
        if(TCI_data.length == 0) {
          errorMessage = "No Images Available";
          return;
        }
        if(imageViewerSelectedImage[0] < TCI_data.length) {
          var displayImage = TCI_data[imageViewerSelectedImage[0]];
          if(imageViewerSelectedImage[1] == 1) {
            displayImage = NDVI_data[imageViewerSelectedImage[0]];
          }
          p.image(displayImage, imageViewerX+imageTranslation[0]*imageViewerW, imageViewerY+imageTranslation[1]*imageViewerH, imageViewerW*imageScale, imageViewerH*imageScale);
        }
        mouseOverImageViewer = mouseBetween(imageViewerX, imageViewerY, imageViewerX+imageViewerW, imageViewerY+imageViewerH);
        var mouseOverLeft = mouseBetween(imageViewerX, imageViewerY, imageViewerX+imageViewerW/2, imageViewerY+imageViewerH/6);
        var mouseOverRight = mouseBetween(imageViewerX+imageViewerW/2, imageViewerY, imageViewerX+imageViewerW, imageViewerY+imageViewerH/6);
        if(TCI_data.length > 0) {
          var isHmouseBetween = hmouseBetween(imageViewerX, imageViewerY, imageViewerX+imageViewerW, imageViewerY+imageViewerH);
          if(isHmouseBetween || (mouseOverImageViewer && (isHmouseBetween || (hmouseX == -1 && hmouseY == -1)))) {
            p.fill(200, 170);
            p.rect(imageViewerX, imageViewerY, imageViewerW, imageViewerH/6);
            var temp_textSize = imageViewer_size/30;
            p.textSize(temp_textSize);
            p.fill(45, 50, 60);
            p.text("True Color Image", imageViewerX+imageViewerW/4, imageViewerY+imageViewerH/12+temp_textSize/2);
            p.text("NDVI Image", imageViewerX+imageViewerW*3/4, imageViewerY+imageViewerH/12+temp_textSize/2);
            p.fill(200, 210, 240, 100);
            if(mouseOverLeft) {
              p.rect(imageViewerX, imageViewerY, imageViewerW/2, imageViewerH/6);
              if(hmouseBetween(imageViewerX, imageViewerY, imageViewerX+imageViewerW/2, imageViewerY+imageViewerH/6)) {
                imageViewerSelectedImage[1] = 0;
                redrawFrames(5);
              }
            }
            if(mouseOverRight) {
              p.rect(imageViewerX+imageViewerW/2, imageViewerY, imageViewerW/2, imageViewerH/6);
              if(hmouseBetween(imageViewerX+imageViewerW/2, imageViewerY, imageViewerX+imageViewerW, imageViewerY+imageViewerH/6)) {
                imageViewerSelectedImage[1] = 1;
                redrawFrames(5);
              }
            }
          }
          p.fill(214, 234, 250);
          p.rect(0, 0, p.width, imageViewerY);
          p.rect(0, 0, imageViewerX, p.height);
          p.rect(imageViewerX+imageViewerW, 0, imageViewerX, p.height);
          p.rect(0, imageViewerY+imageViewerH, p.width, p.height-imageViewerY-imageViewerW);
          if(isHmouseBetween) {
            var relativeMouseX = (p.mouseX-imageViewerX) / imageViewerW;
            var relativeMouseY = (p.mouseY-imageViewerY) / imageViewerH;
            var relativePMouseX = (p.pmouseX-imageViewerX) / imageViewerW;
            var relativePMouseY = (p.pmouseY-imageViewerY) / imageViewerH;
            imageTranslation[0] += (relativeMouseX - relativePMouseX) / 2.5;
            imageTranslation[1] += (relativeMouseY - relativePMouseY) / 2.5;
            imageViewerEdgeCaseTransformation();
          }
          else {
            if(mouseOverImageViewer && !(mouseOverLeft || mouseOverRight) &&imageViewerSelectedImage[1] == 1) {
              var relativeMouseX = (p.mouseX-imageViewerX) / imageViewerW;
              var relativeMouseY = (p.mouseY-imageViewerY) / imageViewerH;
              var imageMouseX = (relativeMouseX - imageTranslation[0]) / imageScale;
              var imageMouseY = (relativeMouseY - imageTranslation[1]) / imageScale;
              var rectTextSize = 12;
              p.textSize(rectTextSize);
              var tempImage = NDVI_data[imageViewerSelectedImage[0]];
              var pixelColor = tempImage.get(imageMouseX*tempImage.width, imageMouseY*tempImage.height);
              var rectText = "NDVI = "+((pixelColor[1]-pixelColor[0])/255).toFixed(3);
              var colorSquareSize = 30;
              var rectPadding = 7;
              var rectWidth = colorSquareSize + p.textWidth(rectText) + rectPadding*3;
              var rectHeight = colorSquareSize + rectPadding*2;
              var rectX = p.mouseX - rectWidth/2;
              var rectY = p.mouseY - rectHeight - rectPadding;
              p.fill(255);
              p.stroke(100);
              p.strokeWeight(1);
              p.rect(rectX, rectY, rectWidth, rectHeight, 5);
              p.fill(pixelColor);
              p.rect(rectX+rectPadding, rectY+rectPadding, colorSquareSize, colorSquareSize);
              p.fill(0);
              p.textAlign(p.LEFT);
              p.text(rectText, rectX+colorSquareSize+rectPadding*2, rectY+rectHeight/2+rectTextSize/2);
            }
          }
        }
      }
      else {
        p.textAlign(p.CENTER);
        p.textSize(20);
        p.fill(255);
        p.text(errorMessage, p.width/2, imageViewerY+imageViewerH/2+10);
      }
    }

    p.textAlign(p.CENTER);
    var showGUI = !downloading && errorMessage == "null" && TCI_data.length > 0;

    // Playbar... (top)
    p.fill(255);
    p.noStroke();
    p.rect(0, downloadButtonSize[1]+20+imageViewer_padding, p.width, playbar_height-imageViewer_padding*2);
    p.fill(0);
    var temp_textSize = imageViewer_size/45;
    p.textSize(temp_textSize);
    p.text("Timelapse:", imageViewerX+imageViewerW/12, imageViewerY-imageViewer_padding-playbar_height/2+imageViewer_padding+temp_textSize/2-2);
    if(showGUI) {
      p.text("Image #"+(playbar_slider.value()+1), imageViewerX+imageViewerW*11/12, imageViewerY-imageViewer_padding-playbar_height/2+imageViewer_padding+temp_textSize/2-2);
    }
    updatePlaybarSlider();
    imageViewerSelectedImage[0] = playbar_slider.value();
    
    // Other Data... (bottom)
    otherDataY = downloadButtonSize[1]+20+playbar_height+imageViewer_size+imageViewer_padding;
    otherDataH = selectionButtons_height;
    p.fill(255);
    p.noStroke();
    p.rect(0, otherDataY, p.width, otherDataH);
    if(showGUI) {
      p.fill(0);
      var temp_textSize = Math.sqrt(p.width)/3;
      p.textSize(temp_textSize);
      p.text("Viewing "+DATE_data[imageViewerSelectedImage[0]], p.width*1/5, otherDataY+otherDataH/2+temp_textSize/2-1);
      imageType = "TCI";
      if(imageViewerSelectedImage[1] == 1) {
        imageType = "NDVI";
      }
      p.text("Image "+(imageViewerSelectedImage[0]+1)+"/"+TCI_data.length+", "+imageType, p.width*2/5, otherDataY+otherDataH/2+temp_textSize/2-1);
      p.text(DATE_data[imageViewerSelectedImage[0]], p.width*3/5, otherDataY+otherDataH/2+temp_textSize/2-1);
      p.text(DATE_data[imageViewerSelectedImage[0]], p.width*4/5, otherDataY+otherDataH/2+temp_textSize/2-1);
    }
  }

  function httpGetAsync(theUrl, callback) {
    var request = new XMLHttpRequest();
    if(request) {
      request.onreadystatechange = function() { 
          if(request.readyState == 4 && request.status == 200) {
            callback(request.responseText);
          }
          else {
            console.log("Request Error: "+request.status);
          }
      }
      request.open("GET", theUrl, true);
      request.withCredentials = "true";
      request.send();
    }
  }
  function getUnixTimestamp(dateString) {
    var dateFormatted = dateString.replaceAll(" ", "").replaceAll("-", "/").replaceAll(",", "/");
    var dateObject = new Date(dateFormatted);
    return dateObject.getTime();
  }

  function downloadData() {
    if(!downloading) {
      console.log("Reseting current data...");
      TCI_data = [];
      NDVI_data = [];
      DATE_data = [];
      imageViewerSelectedPoint = null;
      errorMessage = "null";
      console.log("Starting download thingy...");
      numFramesLeft = -1;
      startDateString = getUnixTimestamp(localStorage.getItem('startDate'));
      endDateString = getUnixTimestamp(localStorage.getItem('endDate'));
      try {
        httpGetAsync(httpURL+"/request?"+processID+"&"+selectedLat+"&"+selectedLon+"&"+startDateString+"&"+endDateString+"&"+sliderSize.value(), requestRecieved);
        downloading = true;
        p.loop();
        p.redraw();
      }
      catch(e) {
        console.log("Unknown Error...\n"+e);
      }
    }
    else {
      console.log("Cannot download new data because data is currently being downloaded...");
    }
  }
  function requestRecieved(response) {
    console.log(response);
    waitForImageResponse = true;
  }
  
  function checkImageDataAvailability() {
    httpGetAsync(httpURL+"/recieve?"+"SENTINEL-DOWNLOADED-DATA-"+processID+"/dataAvailable.txt", checkImageRequestRecieved);
    httpGetAsync(httpURL+"/recieve?"+"SENTINEL-DOWNLOADED-DATA-"+processID+"/error-message.txt", checkImageRequestErrors);
  }
  function checkImageRequestRecieved(response) {
    console.log("Check image request response: "+response);
    if(response === "null") {
      console.log("Trying again...");
    }
    else {
      console.log("Images are available, there are "+response+" sets of images");
      numberOfImageSets = parseInt(response, 10);
      waitForImageResponse = false;
      loadingImageData = true;
    }
  }
  function checkImageRequestErrors(response) {
    console.log("Server Errors: "+response);
    errorMessage = response;
  }

  function getSingleImageData(imageNumber, imageType) {
    var get_img_URL = httpURL+"/recieve?"+"SENTINEL-DOWNLOADED-DATA-"+processID+"/SENTINEL-TEMP-ZIP-"+processID+"-"+imageNumber+"-"+imageType+".jp2";
    var temp_img = p.loadImage(get_img_URL);
    return temp_img;
  }
  function getImageData() {
    console.log("Incoming image data...");
    for(var i = 0; i < numberOfImageSets; i++) {
      // WIP
      TCI_data.push(getSingleImageData(i, 0));
      NDVI_data.push(getSingleImageData(i, 1));
    }
    console.log(TCI_data);
    console.log(NDVI_data);
    loadingImageData = false;
    httpGetAsync(httpURL+"/recieve?"+"SENTINEL-DOWNLOADED-DATA-"+processID+"/date-data.txt", getDateData);
    playbar_slider.remove();
    playbar_slider = p.createSlider(0, TCI_data.length-1, 0, 1);
    updatePlaybarSlider();
  }
  function getDateData(response) {
    console.log("Date Data:\n"+response);
    DATE_data = response.split("\n");
    downloading = false;
  }
};

var p3 = new p5(viewer, 'viewer');


