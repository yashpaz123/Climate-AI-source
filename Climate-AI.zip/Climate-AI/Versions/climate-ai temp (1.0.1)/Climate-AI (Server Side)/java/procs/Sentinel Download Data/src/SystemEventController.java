
public class SystemEventController {
	
	public static void exitWithError(String error) {
		FileFolderHandler.writeFile(Tester.directory+"/error-message.txt", error);
		System.exit(0);
	}
	
}
