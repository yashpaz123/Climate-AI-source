import java.lang.Runnable;
import java.lang.Thread;

public class DownloadXMLThread implements Runnable {
	private Thread t;
	private String threadName;
	private String username;
	private String password;
	private double[] viewPolygon;
	private int start;
	private String startDate;
	private String endDate;

	DownloadXMLThread(String name, double[] vp, String u, String p, int s, String sd, String ed) {
		threadName = name;
		viewPolygon = vp;
		username = u;
		password = p;
		start = s;
		startDate = sd;
		endDate = ed;
		System.out.println("\tCreating thread: " + threadName);
	}

	public void run() {
		String[] XMLrequestData = getXMLURLString(viewPolygon, start, username, password, startDate, endDate);
		System.out.println("\t\t"+threadName+" Request sent: "+XMLrequestData[1]);
		String xmlData = XMLrequestData[0];
		System.out.println("\t\t"+threadName+" Parsing XML data...");
		CustomParser.addImageGranuleToList(xmlData, ListXMLHandler.fullGranuleList, username, password, threadName);
		ListXMLHandler.numThreadsLeft--;
		System.out.println("\t\t"+threadName+" Thread work complete!");
	}

	public static int getTotalResultsSubtitle(String subtitle) {
		System.out.println("\tBatch Subtitle: "+subtitle);
		int startIndex;
		int endIndex;
		if(subtitle.indexOf("of") > -1) {
			startIndex = subtitle.indexOf(" of ") + 4;
			endIndex = subtitle.indexOf(" total ");
		}
		else {
			startIndex = subtitle.indexOf("Displaying ") + 11;
			endIndex = subtitle.indexOf(" results. ");
		}
		
		return Integer.parseInt(subtitle.substring(startIndex, endIndex));
	}
	
	public static String[] getXMLURLString(double[] viewPolygon, int start, String user, String pass, String sDate, String eDate) {
		String formattedURL = HTTPRequestFormatter.formatURL(viewPolygon, start, 100, sDate, eDate);
		String[] XMLURLList = DownloadXML.getXML(formattedURL, user, pass);
		String[] returnArray = new String[2];
		returnArray[0] = String.join("", XMLURLList);
		returnArray[1] = formattedURL;
		return returnArray;
	}
	
	public void start() {
		System.out.println("\tStarting thread: " +  threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
		if(ListXMLHandler.totalResults == -1) {
			String xmlData = getXMLURLString(viewPolygon, 0, username, password, startDate, endDate)[0];
			String subtitle = CustomParser.getXMLComponent(xmlData, "<subtitle>", "</subtitle>");
			ListXMLHandler.totalResults = getTotalResultsSubtitle(subtitle);
		}
	}
}
