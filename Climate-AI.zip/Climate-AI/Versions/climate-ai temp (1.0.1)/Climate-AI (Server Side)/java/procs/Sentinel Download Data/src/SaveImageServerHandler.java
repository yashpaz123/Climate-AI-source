import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class SaveImageServerHandler {
	public static void saveBufferedImage(BufferedImage img, String path) {
		File outputfile = new File(path);
		try {
			ImageIO.write(img, "jp2", outputfile);
		}
		catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error saving: "+path);
		}
	}
}
