
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.spi.ImageReaderSpi;

import com.sun.media.imageioimpl.plugins.jpeg2000.*;

public class JPEG2000Handler {
//	public static void main(String[] args) {
//		System.out.println(getImage("/Users/yash/Downloads/SENTINEL-DOWNLOADED-DATA-a8e1c94558e10dc1/SENTINEL-TEMP-ZIP-a8e1c94558e10dc1-1-0.jp2"));
//	}
	public static BufferedImage getImage(String path) {
		try {
			System.out.println("Loading image byte data ("+path+")...");
			byte[] imageByteData = ConvertJPEG2000Box.getJPEG2000Bytes(path);
			System.out.println(imageByteData.length);
			InputStream imageBytes = new ByteArrayInputStream(imageByteData);
			System.out.println("Decoding image byte data...");
		    return ImageIO.read(imageBytes);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}

