
public class HTTPRequestFormatter {
	public static String formatURL(double[] polygonData, int start, int rows, String startDate, String endDate) {
		String requestURL = "https://scihub.copernicus.eu/dhus/search";
		requestURL += "?q= platformname:Sentinel-2";
		requestURL += " AND beginPosition:["+startDate+" TO "+endDate+"]";
		requestURL += " AND ( footprint:\"Intersects(POLYGON((";
		requestURL += polygonData[1]+" "+polygonData[0]+","+polygonData[3]+" "+polygonData[0]+","+polygonData[3]+" "+polygonData[2]+","+polygonData[1]+" "+polygonData[2]+","+polygonData[1]+" "+polygonData[0];
		requestURL += " )))\")&rows="+rows+"&start="+start;
		return requestURL.replace(" ", "%20").replace("\"", "%22");
	}
}

