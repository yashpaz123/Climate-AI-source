import java.io.IOException;
import java.util.Arrays;

public class SentinelImageGranule {
	public String title;
	public String id;
	public String date;
	public String size;
	public String format;
	
	public double[] footprintX;
	public double[] footprintY;
	public String[] imageURLs; // RED, NIR, TCI
	public int[] cropBounds;
	
	public double[] centerLocation;
	
	public void parseSummary(String summary) {
		String[] splitSummary = summary.split(",");
		date = splitSummary[0].replace("Date: ", "");
	}
	
	public void parseFootprint(String polygon) {
		String noiselessPolygon = polygon.replace("MULTIPOLYGON ", "").replace("POLYGON ", "").replace("(", "").replace(")", "").replace(", ", ",");
		String[] polygonCoordinates = noiselessPolygon.split(",");
		footprintX = new double[polygonCoordinates.length];
		footprintY = new double[polygonCoordinates.length];
		int index = 0;
		for(String coord : polygonCoordinates) {
			String[] parsedCoord = coord.split(" ");
			footprintY[index] = Double.parseDouble(parsedCoord[0]);
			footprintX[index] = Double.parseDouble(parsedCoord[1]);
			index++;
		}
	}
	
	public double[] getBounds() {
		double[] bounds = new double[4];
		bounds[0] = Arrays.stream(footprintX).min().getAsDouble();
		bounds[1] = Arrays.stream(footprintY).max().getAsDouble();
		bounds[2] = Arrays.stream(footprintX).max().getAsDouble();
		bounds[3] = Arrays.stream(footprintY).min().getAsDouble();
		return bounds;	
	}
	
	public void setCenterLocation() {
		centerLocation = new double[2];
//		centerLocation[0] = Arrays.stream(footprintX).average().orElse(Double.NaN);
//		centerLocation[1] = Arrays.stream(footprintY).average().orElse(Double.NaN);
		double[] imageBounds = getBounds();
		centerLocation[0] = (imageBounds[0]+imageBounds[2])/2;
		centerLocation[1] = (imageBounds[1]+imageBounds[3])/2;
	}
	
	public void setCropBounds(double[] location, int size, int resolution) {
		double[] bounds = getBounds();
		cropBounds = ImageCrop.getImageAreaBounds(size, resolution, bounds, location);
	}
	
	public String getLevelData() {
//		String[] parsedTitle = title.split("_");
//		return parsedTitle[1].replace("MSI", "");
		return "L2A";
	}
	
	public String getURL_MTD() {
		return "https://scihub.copernicus.eu/dhus/odata/v1/Products('"+id+"')/Nodes('"+title+".SAFE')/Nodes('MTD_MSI"+getLevelData()+".xml')/$value";
	}
	
	public void setURL_IMG(int resolution, String username, String password, String threadName) throws IOException {
		imageURLs = new String[3];
		int numURLs = 0;
		String urlXML = getURL_MTD();
		System.out.println("\t\t"+threadName+" Downloading XML data: "+urlXML);
		String[] xmlmtd = DownloadXML.getXMLThrow(urlXML, username, password);
		System.out.println("\t\t"+threadName+" Finished downloading");
		for(String ln : xmlmtd) {
			if(ln.indexOf("<IMAGE_FILE>") > -1 && ln.indexOf("</IMAGE_FILE>") > -1 && ln.indexOf("_B04_") > -1 && ln.indexOf("R"+resolution+"m") > -1 && ln.indexOf("_"+resolution+"m") > -1) {
				imageURLs[0] = ln.replace(" ", "");
				numURLs++;
			}
			if(ln.indexOf("<IMAGE_FILE>") > -1 && ln.indexOf("</IMAGE_FILE>") > -1 && ln.indexOf("_B08_") > -1 && ln.indexOf("R"+resolution+"m") > -1 && ln.indexOf("_"+resolution+"m") > -1) {
				imageURLs[1] = ln.replace(" ", "");
				numURLs++;
			}
			if(ln.indexOf("<IMAGE_FILE>") > -1 && ln.indexOf("</IMAGE_FILE>") > -1 && ln.indexOf("_TCI_") > -1 && ln.indexOf("R"+resolution+"m") > -1 && ln.indexOf("_"+resolution+"m") > -1) {
				imageURLs[2] = ln.replace(" ", "");
				numURLs++;
			}
			if(numURLs == 3) {
				break;
			}
		}
	}
	
	public String toString() {
		return "Title: "+title+",   ID: "+id+",   Date: "+date+",   Size: "+size+",\tFormat: "+format;
	}
}
