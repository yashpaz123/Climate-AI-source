
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

public class Tester {
	
	public static double[] location = {40.440543, -74.650060};
	public static long startDate = 1589594115000L;
	public static long endDate = 1592272515000L;
	public static int resolution = 10;
	public static int outputImageSizeLength = 1000;
	public static int numThreads = 4;
	public static int timeThreadWait = 100;
	public static int maxRequestAttemts = 10;
	public static String directory = "/Users/yash/Downloads";
	public static String username = "yashpaz123";
	public static String password = "neXmut-hersy8-qifbuw";
	public static int processIDLength = 16;
	
	public static String processID;
	public static ArrayList<String> downloadedPaths = new ArrayList<String>();
	public static int numMTDThreadsLeft;
	public static double[] viewPolygon;// = {40.78, -73.96, 40.89, -74.1};
	
	public static int numURLsLeft;
	public static int[] availableImageIDs;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		
		System.out.println("--> STARTING SENTINEL DATA DOWNLOAD <--");
		processID = getRandomHexString(processIDLength);
		System.out.println("Process ID: "+processID+"\n");
		
		Runtime rt = Runtime.getRuntime();
		System.out.println("System Runtime Specs:");
		System.out.println("\tVersion: "+rt.version());
		System.out.println("\tRAM Location: "+rt);
		System.out.println("\tAvailable Processors: "+rt.availableProcessors());
		System.out.println("\tFree Memory: "+(rt.freeMemory()/1000000.0)+" MB");
		System.out.println("\tTotal Memory: "+(rt.totalMemory()/1000000.0)+" MB");
		System.out.println("\tMaximum Memory: "+(rt.maxMemory()/1000000.0)+" MB");
		System.out.println("\tHash Code: "+rt.hashCode()+" [Integer RAM]");
		
		Tester.directory += "/SENTINEL-DOWNLOADED-DATA-"+Tester.processID;
		System.out.println("Creating boiler plate directory...");
		FileFolderHandler.createFolder(Tester.directory);
		FileFolderHandler.createFile(Tester.directory+"/dataAvailable.txt");
		FileFolderHandler.createFile(Tester.directory+"/date-data.txt");
		FileFolderHandler.createFile(Tester.directory+"/error-message.txt");
		FileFolderHandler.writeFile(Tester.directory+"/dataAvailable.txt", "null");
		FileFolderHandler.writeFile(Tester.directory+"/error-message.txt", "null");
		System.out.println("Created files succesfully!");
		
		viewPolygon = new double[4];
		viewPolygon[0] = location[0] - 0.05;
		viewPolygon[1] = location[1] + 0.05;
		viewPolygon[2] = location[0] + 0.05;
		viewPolygon[3] = location[1] - 0.05;
		
		System.out.println("\nDownloading XML URL list...");
		
		
		ArrayList<SentinelImageGranule> fullGranuleList = ListXMLHandler.getFullGranuleList(viewPolygon, username, password, startDate, endDate);
		
		
		/*
		 * TODO:
		 * Separate different regions of satellite images.
		 * Since they are not exactly in the same locations, perform cluster analysis on centers of images.
		 * Calculate average location of each cluster, and choose images from cluster whose center is closest to the desired location.
		 */
		for(SentinelImageGranule g : fullGranuleList) {
			g.setCenterLocation();
		}
		
		for(SentinelImageGranule g : fullGranuleList) {
			System.out.println("("+(g.centerLocation[0]*100)+", "+(g.centerLocation[1]*100)+")");
		}
//		System.exit(0);
		
		
		
		System.out.println("\nCalculating image bounding boxes (to crop)...");
		for(SentinelImageGranule g : fullGranuleList) {
			g.setCropBounds(location, outputImageSizeLength, resolution);
		}
		for(SentinelImageGranule g : fullGranuleList) {
			System.out.println(g.cropBounds[0]+", "+g.cropBounds[1]+", "+g.cropBounds[2]+", "+g.cropBounds[3]);
		}
		System.out.println("Done!");
		
		
		
		
		
		System.out.println("\nDownloading granule path data (MTD)...");
		ArrayList<DownloadXMLMTDThread> mtdThreads = new ArrayList<DownloadXMLMTDThread>();
		System.out.println("Creating MTD threads:");
		numMTDThreadsLeft = fullGranuleList.size();
		for(int i = 0; i < fullGranuleList.size(); i++) {
			SentinelImageGranule g = fullGranuleList.get(i);
			mtdThreads.add(new DownloadXMLMTDThread("[MTDThread-"+(i+1)+"]", username, password, resolution, g));
		}
		
		System.out.println("Starting MTD threads:");
		for(DownloadXMLMTDThread thread : mtdThreads) {
			thread.start();
		}
		System.out.println("\t[System] Waiting for thread(s) to complete ["+timeThreadWait+"ms]...");
		while(numMTDThreadsLeft > 0) {
			try {
				Thread.sleep(timeThreadWait);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("\nThese are the downloaded granule paths:");
		for(SentinelImageGranule g : fullGranuleList) {
			System.out.println("\tID = "+g.id+":");
			for(String imageURL : g.imageURLs) {
				System.out.println("\t\t"+imageURL);
			}
		}
		
		
		DownloadURLHandler.downloadImages(fullGranuleList, username, password);
		
		System.out.println("\nThese are the available image granule indices:");
		for(int i : availableImageIDs) {
			System.out.println("\tIndex "+i+":");
			System.out.println("\t\t"+fullGranuleList.get(i));
		}
		
		ImageProcessorHandler.processImages(availableImageIDs, fullGranuleList);
		ImageProcessorHandler.saveImages();
		
	}

	private static String getRandomHexString(int numchars) {
		Random r = new Random();
		StringBuffer sb = new StringBuffer();
		while(sb.length() < numchars){
			sb.append(Integer.toHexString(r.nextInt()));
		}
		return sb.toString().substring(0, numchars);
	}
}

