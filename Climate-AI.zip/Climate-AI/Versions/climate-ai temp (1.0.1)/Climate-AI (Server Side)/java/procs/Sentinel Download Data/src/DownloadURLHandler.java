import java.io.File;
import java.util.ArrayList;

public class DownloadURLHandler {
	public static void downloadImages(ArrayList<SentinelImageGranule> fullGranuleList, String username, String password) {
		
		System.out.println("\nDownloading image data...");
		Tester.numURLsLeft = fullGranuleList.size() * 3;
		int totalURLs = fullGranuleList.size();
		
		ArrayList<DownloadURLThread> threads = new ArrayList<DownloadURLThread>();
		
		System.out.println("Creating URL threads:");
		for(int i = 0; i < fullGranuleList.size(); i++) {
			SentinelImageGranule g = fullGranuleList.get(i);
			for(int n = 0; n < g.imageURLs.length; n++) {
				String url = g.imageURLs[n];
				threads.add(new DownloadURLThread("[Thread-"+(i+1)+"-"+(n+1)+"]", url, Tester.directory+"/SENTINEL-TEMP-ZIP-"+Tester.processID+"-"+i+"-"+n+".jp2", username, password));
			}
		}
		
		System.out.println("Starting URL threads:");
		for(DownloadURLThread thread : threads) {
			thread.start();
		}
		
		
		System.out.println("\t[System] Waiting for thread(s) to complete ["+Tester.timeThreadWait+"ms]...");
		while(Tester.numURLsLeft > 0) {
			try {
				Thread.sleep(Tester.timeThreadWait);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("SUCCESS: Image data downloaded!");
		
		System.out.println("\nGenerating list of succeeded image downloads...");
		Tester.availableImageIDs = VerifyImages.getActiveImageIDs(totalURLs);
	}
}
