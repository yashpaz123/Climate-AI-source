import java.awt.image.BufferedImage;

public class ImageCrop {
	public static int getPixelLength(int resolution) {
		int pixelLength = 0;
		if(resolution == 10) {
			pixelLength = 10980;
		}
		if(resolution == 20) {
			pixelLength = 5490;
		}
		if(resolution == 60) {
			pixelLength = 1830;
		}
		return pixelLength;
	}
	
	public static double[] imageProjectedLocation(int resolution, double[] bounds, double[] location) {
		int pixelLength = getPixelLength(resolution);
		double[] projectedLocation = new double[2];
		projectedLocation[1] = pixelLength * (location[0]-bounds[2]) / (bounds[0]-bounds[2]);
		projectedLocation[0] = pixelLength * (location[1]-bounds[3]) / (bounds[1]-bounds[3]);
		return projectedLocation;
	}
	
	public static int[] getImageAreaBounds(int size, int resolution, double[] bounds, double[] location) {
		double[] pixelCoord = imageProjectedLocation(resolution, bounds, location);
		int[] areaBounds = new int[4];
		areaBounds[0] = (int)Math.round(pixelCoord[0] - size/2.0);
		areaBounds[1] = (int)Math.round(pixelCoord[1] - size/2.0);
		areaBounds[2] = (int)Math.round(pixelCoord[0] + size/2.0);
		areaBounds[3] = (int)Math.round(pixelCoord[1] + size/2.0);
		int pixelLength = getPixelLength(resolution);
		for(int i = 0; i < areaBounds.length; i++) {
			if(areaBounds[i] < 0) {
				areaBounds[i] = 0;
			}
			if(areaBounds[i] > pixelLength - 1) {
				areaBounds[i] = pixelLength - 1;
			}
		}
		return areaBounds;
	}
}
