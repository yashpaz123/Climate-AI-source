import java.io.File;
import java.util.ArrayList;

public class VerifyImages {
	public static boolean imageExists(int imageID) {
		String baseFile = Tester.directory+"/SENTINEL-TEMP-ZIP-"+Tester.processID+"-"+imageID;
		File img0 = new File(baseFile+"-0.jp2");
		File img1 = new File(baseFile+"-1.jp2");
		File img2 = new File(baseFile+"-2.jp2");
		return img0.isFile() && img1.isFile() && img2.isFile();
	}
	
	public static int[] getActiveImageIDs(int numIDs) {
		ArrayList<Integer> activeImageIDs = new ArrayList<Integer>();
		for(int i = 0; i < numIDs; i++) {
			if(imageExists(i)) {
				activeImageIDs.add(i);
			}
		}
        return activeImageIDs.stream().mapToInt(i->i).toArray();
	}
}
