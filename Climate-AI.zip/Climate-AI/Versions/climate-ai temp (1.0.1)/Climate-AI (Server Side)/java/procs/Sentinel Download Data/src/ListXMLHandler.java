import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

public class ListXMLHandler {
	public static ArrayList<SentinelImageGranule> fullGranuleList = new ArrayList<SentinelImageGranule>();
	public static int totalResults = -1;
	public static int numThreads = 0;
	public static int numThreadsLeft;
	
	public static ArrayList<SentinelImageGranule> getFullGranuleList(double[] viewPolygon, String username, String password, long startDate, long endDate) {
		String sDate = getISODate(startDate);
		String eDate = getISODate(endDate);
		
		System.out.println("Request date range: "+sDate+" to "+eDate);
		
		ArrayList<DownloadXMLThread> threads = new ArrayList<DownloadXMLThread>();
		System.out.println("Starting XML threads:");
		int threadNumber = 1;
		while(true) {
			DownloadXMLThread thread = new DownloadXMLThread("[Thread-"+threadNumber+"]", viewPolygon, username, password, (threadNumber-1)*100, sDate, eDate);
			threads.add(thread);
			thread.start();
			numThreads++;
			if(numThreads >= Math.ceil(totalResults/100.0)) {
				break;
			}
			threadNumber++;
		}
		numThreadsLeft = numThreads;
		System.out.println("\t[System] Waiting for thread(s) to complete ["+Tester.timeThreadWait+"ms]...");
		while(numThreadsLeft > 0) {
			if(totalResults == 0) {
				System.out.println("Stopping threads since totalResults = 0");
				break;
			}
			try {
				Thread.sleep(Tester.timeThreadWait);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("Setting threads to null...");
		threads = null;
		
		System.out.println("\nSuccess, XML metadata follows:");
		System.out.println("\tTotal available XML page results: "+totalResults);
		System.out.println("\tTotal downloaded XML page results: "+fullGranuleList.size());
		System.out.println("\tXML list RAM location: @"+Integer.toHexString(System.identityHashCode(fullGranuleList)));
		System.out.println("\nThese are the granule data (to be downloaded):");
		for(SentinelImageGranule g : fullGranuleList) {
			System.out.println("\t"+g);
		}
		
		// Delete any granule objects with same id
		// Reorder granules from earliest to latest
		// Create new object for storing batches of granules taken during the same time
		// Algorithm for pasting multiple areas of polgon images to make one coherent image of the selected region
		// Find way to download only the image data (TCI, B04, B08)
		// Document all this, the correct url format, multithreading the xml, etc.
		
		return fullGranuleList;
	}
	
	public static String getISODate(long date) {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:00.000'Z'");
		df.setTimeZone(tz);
		String formattedDate = df.format(new Date(date));
		return formattedDate;
	}
	
}
