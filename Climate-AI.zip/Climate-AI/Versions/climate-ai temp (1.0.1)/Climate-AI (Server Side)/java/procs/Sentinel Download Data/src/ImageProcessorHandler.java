import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class ImageProcessorHandler {
	public static BufferedImage[] imageDataRED;
	public static BufferedImage[] imageDataNIR;
	public static BufferedImage[] imageDataTCI;
	
	public static int numThreadsLeft;
	
	public static void processImages(int[] availableIDs, ArrayList<SentinelImageGranule> fullGranuleList) {
		imageDataRED = new BufferedImage[availableIDs.length];
		imageDataNIR = new BufferedImage[availableIDs.length];
		imageDataTCI = new BufferedImage[availableIDs.length];
		
		System.out.println("\nInitializing Image Processing Threads:");
		ArrayList<ImageProcessorThread> threads = new ArrayList<ImageProcessorThread>();
		numThreadsLeft = availableIDs.length;
		for(int i = 0; i < availableIDs.length; i++) {
			threads.add(new ImageProcessorThread("Thread-"+(i+1), availableIDs[i], i, fullGranuleList));
		}
		for(ImageProcessorThread thread : threads) {
			thread.start();
		}
		
		System.out.println("\t[System] Waiting for thread(s) to complete ["+Tester.timeThreadWait+"ms]...");
		while(numThreadsLeft > 0) {
			try {
				Thread.sleep(Tester.timeThreadWait);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("SUCCESS: Image data processed!");
	}
	
	public static void saveImages() {
		
	}
}
