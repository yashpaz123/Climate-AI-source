
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.sun.media.imageioimpl.plugins.jpeg2000.*;

import jj2000.j2k.io.BEBufferedRandomAccessFile;
import jj2000.j2k.io.RandomAccessIO;

public class ConvertJPEG2000Box {
	public static byte[] getJPEG2000Bytes(String imagePath) throws IOException {
		ByteArrayOutputStream imageByteData = new ByteArrayOutputStream();
	    RandomAccessIO in = new BEBufferedRandomAccessFile(imagePath, "r");
	    DataOutputStream out = new DataOutputStream(imageByteData);
	    boolean done = false;
	    while (!done) {
	        try {
	            int boxLength = in.readInt();
	            if (boxLength == 1) {
	                //convert large box
	                int boxType = in.readInt();//skip box type
	                long actualBoxLength = in.readLong();//the box is actually small
	                if (actualBoxLength > Integer.MAX_VALUE) {
	                    throw new RuntimeException("Unable to fix large box, size exceeds int");
	                }
	                out.writeInt((int) actualBoxLength - 8);
	                out.writeInt(boxType);
	                copyBytes(in, out, (int) actualBoxLength - 16);
	            } else {
	                //copy other stuff
	                out.writeInt(boxLength);
	                copyBytes(in, out, boxLength != 0 ? boxLength - 4 : 0);
	            }
	        }
	        catch (EOFException e) {
	        	System.out.println("The following error message is most likely redundant...");
	        	e.printStackTrace();
	            done = true;
	        }
	    }
	    out.close();
	    in.close();
	    if(imageByteData != null) {
	    	imageByteData.close();
	    }
	    return imageByteData.toByteArray();
	}

	private static void copyBytes(RandomAccessIO in, DataOutputStream out, int length) throws IOException {
	    if (length != 0) {
	        //copying set amount
	        byte[] bytes = new byte[length];
	        in.readFully(bytes, 0, bytes.length);
	        out.write(bytes, 0, bytes.length);
	    } else {
	        //copying to the end of file
	        byte[] bytes = new byte[10240];
	        int lastPos = 0;
	        try {
	            while (true) {
	                lastPos = in.getPos();
	                in.readFully(bytes, 0, bytes.length);
	                out.write(bytes, 0, bytes.length);
	            }
	        } catch (EOFException e) {
	            out.write(bytes, 0, in.length() - lastPos);
	        }
	    }
	}
}


