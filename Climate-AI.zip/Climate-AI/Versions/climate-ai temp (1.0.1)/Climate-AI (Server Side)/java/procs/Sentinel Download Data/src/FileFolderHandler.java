import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileFolderHandler {
	
	public static void createFolder(String dir) {
		System.out.println("\nCreating directory \""+dir+"\"");
		boolean folderCreationSuccess = (new File(dir)).mkdirs();
		if(!folderCreationSuccess) {
			System.out.println("Unable to create directory \""+dir+"\"\nTERMINATED");
			SystemEventController.exitWithError("Server Error [CREATE-DIR]");
		}
	}
	
	public static void createFile(String path) {
		try {
			boolean fileCreationSuccess = (new File(path)).createNewFile();
			if(!fileCreationSuccess) {
				System.out.println("Unable to create file \""+path+"\"\nTERMINATED");
				SystemEventController.exitWithError("Server Error [CREATE-FILE]");
			}
		}
		catch(IOException e) {
			System.out.println("Unknown IOException!");
			e.printStackTrace();
			System.out.println("TERMINATED");
			SystemEventController.exitWithError("Server Error [UNKNOWN-CREATE-FILE]");
		}
	}
	
	public static void writeFile(String path, String data) {
		try {
			FileOutputStream outputStream = new FileOutputStream(path);
			byte[] strToBytes = data.getBytes();
			outputStream.write(strToBytes);
			outputStream.close();
		}
		catch(IOException e) {
			e.printStackTrace();
			System.out.println("System will not terminate (attempting to resolve issue)...");
		}
	}
	
}

