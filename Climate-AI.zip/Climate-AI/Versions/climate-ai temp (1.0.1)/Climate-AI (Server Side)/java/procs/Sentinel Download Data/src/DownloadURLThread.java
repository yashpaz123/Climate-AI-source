import java.io.IOException;
import java.lang.Runnable;
import java.lang.Thread;


class DownloadURLThread implements Runnable {
	private Thread t;
	private String threadName;
	private String url;
	private String username;
	private String password;
	private String filePath;

	DownloadURLThread(String name, String ur, String fp, String u, String p) {
		threadName = name;
		url = ur;
		filePath = fp;
		username = u;
		password = p;
		System.out.println("\tCreating thread: " + threadName);
	}

	public void run() {
		System.out.println("\t"+threadName+": Downloading \""+url+"\"...");
		boolean succeeded = false;
		for(int i = 0; i < Tester.maxRequestAttemts; i++) {
			try {
				DownloadURL.saveImageURL(url, filePath, username, password, threadName);
				succeeded = true;
				break;
			}
			catch(IOException ioe) {
				ioe.printStackTrace();
				System.out.println("\t"+threadName+" Encountered error, trying again (max "+Tester.maxRequestAttemts+" times)...");
			}
		}
		Tester.numURLsLeft--;
		if(succeeded) {
			System.out.println("\t"+threadName+" Thread work complete!");
		}
		else {
			System.out.println("\t"+threadName+" Thread gave up, unable to download image.");
		}
		System.out.println("\t"+threadName+": Process ended!");
	}

	public void start() {
		System.out.println("\tStarting thread: " +  threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}
}
