//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileReader;
//import java.io.IOException;
import java.util.ArrayList;

public class CustomParser {
	
	public static void addImageGranuleToList(String xml, ArrayList<SentinelImageGranule> granuleList, String username, String password, String threadName) {
		ArrayList<String> entryList = new ArrayList<String>();
		String currentEntry = "";
		boolean recordEntry = false;
		String currentToken = "";
		boolean recordToken = false;
		
		for(int i = 0; i < xml.length(); i++) {
			char c = xml.charAt(i);
			if(c == '<') {
				recordToken = true;
			}
			if(recordToken) {
				currentToken += c;
			}
			if(c == '>') {
				recordToken = false;
			}
			if(recordEntry) {
				currentEntry += c;
			}
			if(!recordToken) {
				if(currentToken.equals("<entry>")) {
					recordEntry = true;
				}
				if(currentToken.equals("</entry>")) {
					recordEntry = false;
					entryList.add(currentEntry);
					currentEntry = "";
				}
				currentToken = "";
			}
		}
		System.out.println("\t\t"+threadName+" Adding granules to list ("+entryList.size()+" total)...");
		int totalAddedGranules = 0;
		for(String entryData : entryList) {
			SentinelImageGranule g = getImageGranule(entryData, username, password, threadName);
			if(g.format.equals("SAFE") && g.title.indexOf("MSIL2A") > -1) {
				granuleList.add(g);
				totalAddedGranules++;
			}
		}
		System.out.println("\t\t"+threadName+" Success: added granules to list ("+totalAddedGranules+" total)...");
	}
	
	public static String getXMLComponent(String XMLEntryData, String XMLOpenTag, String XMLCloseTag) {
		int startIndex = XMLEntryData.indexOf(XMLOpenTag) + XMLOpenTag.length();
		int endIndex = XMLEntryData.indexOf(XMLCloseTag, startIndex+1);
		return XMLEntryData.substring(startIndex, endIndex);
	}
	
	public static SentinelImageGranule getImageGranule(String XMLEntryData, String username, String password, String threadName) {
		SentinelImageGranule imageGranule = new SentinelImageGranule();
		imageGranule.title = getXMLComponent(XMLEntryData, "<title>", "</title>");
		imageGranule.id = getXMLComponent(XMLEntryData, "<id>", "</id>");
		imageGranule.parseSummary(getXMLComponent(XMLEntryData, "<summary>", "</summary>"));
		imageGranule.size = getXMLComponent(XMLEntryData, "<str name=\"size\">", "</str>");
		imageGranule.format = getXMLComponent(XMLEntryData, "<str name=\"format\">", "</str>");
		imageGranule.parseFootprint(getXMLComponent(XMLEntryData, "<str name=\"footprint\">", "</str>"));
		return imageGranule;
	}
	
	
	
	
	
//	public static String readFile(String path) {
//		String thisLine = null;
//		String fileData = "";
//		BufferedReader br = null;
//		try {
//			File file = new File(path);
//			br = new BufferedReader(new FileReader(file));
//			while((thisLine = br.readLine()) != null) {
//				fileData += thisLine;
//			}
//			br.close();
//			return fileData;
//		}
//		catch(IOException e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
}
