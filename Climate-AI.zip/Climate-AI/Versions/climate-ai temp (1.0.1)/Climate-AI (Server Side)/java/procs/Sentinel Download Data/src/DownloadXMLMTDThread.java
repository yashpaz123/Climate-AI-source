import java.io.IOException;
import java.lang.Runnable;
import java.lang.Thread;

public class DownloadXMLMTDThread implements Runnable {
	private Thread t;
	private String threadName;
	private String username;
	private String password;
	private int resolution;
	private SentinelImageGranule granule;

	DownloadXMLMTDThread(String name, String u, String p, int r, SentinelImageGranule g) {
		threadName = name;
		username = u;
		password = p;
		resolution = r;
		granule = g;
		System.out.println("\tCreating thread: " + threadName);
	}

	public void run() {
		boolean succeeded = false;
		for(int i = 0; i < Tester.maxRequestAttemts; i++) {
			try {
				granule.setURL_IMG(resolution, username, password, threadName);
				for(int n = 0; n < granule.imageURLs.length; n++) {
					String[] parsedImagesURL = granule.imageURLs[n].replace("<IMAGE_FILE>", "").replace("</IMAGE_FILE>", "").split("/");
					String fullImageURL = "https://scihub.copernicus.eu/dhus/odata/v1/Products('"+granule.id+"')/Nodes('"+granule.title+".SAFE')";
					fullImageURL += "/Nodes('"+parsedImagesURL[0]+"')";
					fullImageURL += "/Nodes('"+parsedImagesURL[1]+"')";
					fullImageURL += "/Nodes('"+parsedImagesURL[2]+"')";
					fullImageURL += "/Nodes('"+parsedImagesURL[3]+"')";
					fullImageURL += "/Nodes('"+parsedImagesURL[4]+".jp2')";
					fullImageURL += "/$value";
					granule.imageURLs[n] = fullImageURL;
				}
				succeeded = true;
				break;
			}
			catch(IOException ioe) {
				ioe.printStackTrace();
				System.out.println("\t"+threadName+" Encountered error, trying again (max "+Tester.maxRequestAttemts+" times)...");
			}
		}
		Tester.numMTDThreadsLeft--;
		if(succeeded) {
			System.out.println("\t"+threadName+" Thread work complete!");
		}
		else {
			System.out.println("\t"+threadName+" Thread gave up, unable to download XML MTD.");
		}
	}
	
	public void start() {
		System.out.println("\tStarting thread: " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}
}
