import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;

//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.io.InputStream;
//import java.net.MalformedURLException;
//import java.nio.channels.Channels;
//import java.nio.channels.FileChannel;
//import java.nio.channels.ReadableByteChannel;
//import java.nio.file.Files;
//import java.nio.file.StandardCopyOption;

//import java.io.BufferedInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.net.URL;

public class DownloadURL {
	
	// Temporary buffers allow program to download gigabytes of data without storing all in RAM.
	// 2 GB file takes as little as 100 MB RAM.
	public static void saveImageURL(String url, String path, String username, String password, String threadName) throws MalformedURLException, IOException {
		System.out.println("\t\t"+threadName+": Authenticating credentials...");
		ServerAuthenticator.setPasswordAuthentication(username, password);
        Authenticator.setDefault(new ServerAuthenticator());
        
        System.out.println("\t\t"+threadName+": Opening buffered input stream...");
        BufferedInputStream in = new BufferedInputStream(new URL(url).openStream());
        byte data[] = new byte[1024];
        int count;
        FileOutputStream out = new FileOutputStream(path);
        System.out.println("\t\t"+threadName+": Writing data...");
        while((count = in.read(data,0,1024)) != -1) {
        	out.write(data, 0, count);
        }
        System.out.println("\t\t"+threadName+": Closing buffered input stream...");
        out.close();
	}
}

