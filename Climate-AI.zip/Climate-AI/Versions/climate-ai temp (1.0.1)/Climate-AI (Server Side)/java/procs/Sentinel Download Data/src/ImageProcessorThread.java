import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.Runnable;
import java.lang.Thread;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class ImageProcessorThread implements Runnable {
	private Thread t;
	private String threadName;
	private int id;
	private int index;
	private ArrayList<SentinelImageGranule> granules;

	ImageProcessorThread(String name, int ID, int indx, ArrayList<SentinelImageGranule> fullGranuleList) {
		threadName = name;
		id = ID;
		index = indx;
		granules = fullGranuleList;
		System.out.println("\tCreating thread: " + threadName);
	}

	public void run() {
		String baseFile = Tester.directory+"/SENTINEL-TEMP-ZIP-"+Tester.processID+"-"+id;
		String pathRED = baseFile+"-0.jp2";
		String pathNIR = baseFile+"-1.jp2";
		String pathTCI = baseFile+"-2.jp2";
		BufferedImage red = ImageProcessorHandler.imageDataRED[index];
		BufferedImage nir = ImageProcessorHandler.imageDataNIR[index];
		BufferedImage tci = ImageProcessorHandler.imageDataTCI[index];

		System.out.println("\t["+threadName+"]: Loading image data from disk...");
		red = getImage(pathRED);
		if(red == null) {
			System.out.println("\t["+threadName+"]: Unknown Server File Error (Missing RED) - "+pathRED);
			ImageProcessorHandler.numThreadsLeft--;
			return;
		}
		nir = getImage(pathNIR);
		if(nir == null) {
			System.out.println("\t["+threadName+"]: Unknown Server File Error (Missing NIR) - "+pathNIR);
			ImageProcessorHandler.numThreadsLeft--;
			return;
		}
		tci = getImage(pathTCI);
		if(tci == null) {
			System.out.println("\t["+threadName+"]: Unknown Server File Error (Missing TCI) - "+pathTCI);
			ImageProcessorHandler.numThreadsLeft--;
			return;
		}
		
		System.out.println("\t["+threadName+"]: Cropping images...");
		int x = granules.get(id).cropBounds[0];
		int y = granules.get(id).cropBounds[1];
		int w = granules.get(id).cropBounds[2] - x;
		int h = granules.get(id).cropBounds[3] - y;
		ImageProcessorHandler.imageDataRED[index] = getSafeSubimage(red, x, y, w, h);
		ImageProcessorHandler.imageDataNIR[index] = getSafeSubimage(nir, x, y, w, h);
		ImageProcessorHandler.imageDataTCI[index] = getSafeSubimage(tci, x, y, w, h);
		
		System.out.println("\t["+threadName+"]: Saving images to disk...");
		String baseOutputFile = Tester.directory+"/SENTINEL-DATA-"+Tester.processID+"-"+id;
		SaveImageServerHandler.saveBufferedImage(red, baseOutputFile+"-0.jp2");
		
		System.out.println("\t["+threadName+"]: Process ended!");
		ImageProcessorHandler.numThreadsLeft--;
	}
	
	public void start() {
		System.out.println("\tStarting thread: " +  threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}
	
	private BufferedImage getImage(String path) {
		return JPEG2000Handler.getImage(path);
	}
	
	private BufferedImage getSafeSubimage(BufferedImage img, int x, int y, int w, int h) {
		return img.getSubimage(Math.max(x, 0), Math.max(y, 0), Math.min(w, 10980-1-x), Math.min(h, 10980-1-y));
	}
}

