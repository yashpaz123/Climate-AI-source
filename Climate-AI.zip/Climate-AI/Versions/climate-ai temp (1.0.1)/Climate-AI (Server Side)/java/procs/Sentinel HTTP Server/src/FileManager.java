import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileManager {
	public static byte[] getFileBytes(String filePath) throws FileNotFoundException {
		File file = new File(filePath);

		FileInputStream fis = new FileInputStream(file);
		//System.out.println(file.exists() + "!!");
		//InputStream in = resource.openStream();
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		try {
			for(int readNum; (readNum = fis.read(buf)) != -1;) {
				bos.write(buf, 0, readNum);
			}
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
		byte[] bytes = bos.toByteArray();

		return bytes;
	}
}
