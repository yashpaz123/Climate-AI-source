import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URL;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpPrincipal;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.net.InetAddress;

public class Tester {
	public static int port = 8500;
	public static String directory = "/Users/yash/Downloads";
	public static boolean verbose = true;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		System.out.println("Starting Server (Climate AI)...\n");
		Runtime rt = Runtime.getRuntime();
		System.out.println("System Runtime Specs:");
		System.out.println("\tVersion: "+rt.version());
		System.out.println("\tRAM Location: "+rt);
		System.out.println("\tAvailable Processors: "+rt.availableProcessors());
		System.out.println("\tFree Memory: "+(rt.freeMemory()/1000000.0)+" MB");
		System.out.println("\tTotal Memory: "+(rt.totalMemory()/1000000.0)+" MB");
		System.out.println("\tMaximum Memory: "+(rt.maxMemory()/1000000.0)+" MB");
		System.out.println("\tHash Code: "+rt.hashCode()+" [Integer RAM]\n");
		
		try {
			HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

			String ip = InetAddress.getLocalHost().getHostAddress();
			System.out.println("Server Private IP: "+ip);
			
			URL whatismyip = new URL("http://checkip.amazonaws.com");
			BufferedReader in = new BufferedReader(new InputStreamReader(whatismyip.openStream()));

			String ip2 = in.readLine();
			System.out.println("Server Public IP"+ip2);
			String accessURL = "http://"+ip+":"+port;
			System.out.println("Server Access URl: "+accessURL+"\n");
			System.out.println("For request context type: "+accessURL+"/request?<YOUR QUERY>");
			System.out.println("For recieve context type: "+accessURL+"/recieve?<YOUR PATH>\n");

			HttpContext contextRequest = server.createContext("/request");
			contextRequest.setHandler(Tester::handleRequest);

			HttpContext contextRecieve = server.createContext("/recieve");
			contextRecieve.setHandler(Tester::handleRecieve);
			
			server.start();
		}
		catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}

	// When user first contacts server "GET" request
	public static void handleRequest(HttpExchange exchange) throws IOException {
		setCORS(exchange.getRequestHeaders(), exchange.getResponseHeaders());
		
		URI requestURI = exchange.getRequestURI();
		System.out.println("REQUEST");
		if(verbose) {
			printRequestInfo(exchange);
		}
		String response = getResponse(requestURI.getQuery());
		exchange.sendResponseHeaders(200, response.getBytes().length);
		OutputStream os = exchange.getResponseBody();
		os.write(response.getBytes());
		os.close();
	}
	
	// When user requests for data
	public static void handleRecieve(HttpExchange exchange) throws IOException {
		setCORS(exchange.getRequestHeaders(), exchange.getResponseHeaders());
		
		URI requestURI = exchange.getRequestURI();
		System.out.println("RECIEVE");
		if(verbose) {
			printRequestInfo(exchange);
		}
		byte[] response = getRecieveByteData(requestURI.getQuery());
		System.out.println("\tSending byte data...");
		exchange.sendResponseHeaders(200, response.length);
		OutputStream os = exchange.getResponseBody();
		os.write(response);
		os.close();
	}
	
	public static void setCORS(Headers requestHeaders, Headers responseHeaders) {
		String origin = requestHeaders.getFirst("Origin");
		if(origin == null) {
			origin = "null";
		}
		responseHeaders.set("Allow", "GET,PUT,POST,DELETE,OPTIONS");
		responseHeaders.set("Access-Control-Allow-Origin", origin);
		responseHeaders.set("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
		responseHeaders.set("Access-Control-Allow-Headers", "Content-Type");
		responseHeaders.set("Access-Control-Request-Methods", "GET,PUT,POST,DELETE,OPTIONS");
		responseHeaders.set("Access-Control-Request-Headers", "Content-Type");
		responseHeaders.set("Access-Control-Max-Age", "3600");
		responseHeaders.set("Access-Control-Allow-Credentials", "true");
	}

	public static void printRequestInfo(HttpExchange exchange) {
		System.out.println("-- headers --");
		Headers requestHeaders = exchange.getRequestHeaders();
		requestHeaders.entrySet().forEach(System.out::println);

		System.out.println("-- principle --");
		HttpPrincipal principal = exchange.getPrincipal();
		System.out.println(principal);

		System.out.println("-- HTTP method --");
		String requestMethod = exchange.getRequestMethod();
		System.out.println(requestMethod);

		System.out.println("-- query --");
		URI requestURI = exchange.getRequestURI();
		String query = requestURI.getQuery();
		System.out.println(query);
	}
	
	public static String getResponse(String query) {
		System.out.println("\tRecieved query: "+query);
		String[] parsedQuery = query.split("&");
		String processID = parsedQuery[0];
		double latitude = Double.parseDouble(parsedQuery[1]);
		double longitude = Double.parseDouble(parsedQuery[2]);
		long startTime = Long.parseLong(parsedQuery[3]);
		long endTime = Long.parseLong(parsedQuery[4]);
		int imageSize = Integer.parseInt(parsedQuery[5]);
		
		String response = processID+"\n"+latitude+"\n"+longitude+"\n"+startTime+"\n"+endTime+"\n"+imageSize;
		
		return response;
	}
	
	public static byte[] getRecieveByteData(String query) throws FileNotFoundException {
		System.out.println("\tRecieved query: "+query);
		String path = directory+"/"+query;
		byte[] byteData = null;
		byteData = FileManager.getFileBytes(path);
		System.out.println("\tRetrieved file \""+path+"\" of length: "+byteData.length);
		return byteData;
	}
}

